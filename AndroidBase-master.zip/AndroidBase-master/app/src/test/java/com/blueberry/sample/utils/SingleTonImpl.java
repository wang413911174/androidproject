package com.blueberry.sample.utils;

/**
 * Created by blueberry on 2016/8/29.
 */
public class SingleTonImpl extends SingleTon {
    public SingleTonImpl(){
        super();
    }
}
