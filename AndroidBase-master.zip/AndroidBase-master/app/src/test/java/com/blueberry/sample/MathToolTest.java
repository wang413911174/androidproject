package com.blueberry.sample;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Created by blueberry on 2016/8/22.
 */
public class MathToolTest extends TestCase {
    public MathToolTest(String testMethod){
        super(testMethod);
    }

    public void testGcd(){
    }

    public static void main(String[] args){
    }
}
