package com.blueberry.sample.module.data_binding;

/**
 * Created by blueberry on 2016/9/21.
 */

public class Image {
    private String url;

    public Image(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }


}
