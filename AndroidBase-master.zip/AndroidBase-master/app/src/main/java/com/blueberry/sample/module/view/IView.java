package com.blueberry.sample.module.view;

import com.blueberry.sample.module.view.data.ViewBean;

import java.util.List;

/**
 * Created by blueberry on 2016/6/17.
 */
public interface IView {

    void showData(List<ViewBean> datas);
}
