package com.blueberry.sample.common;

import android.support.v4.app.Fragment;

/**
 * Created by blueberry on 2016/8/9.
 */
public class BaseFragment extends Fragment{
}
