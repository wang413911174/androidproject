package com.blueberry.sample.common;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by blueberry on 2016/5/5.
 */
public abstract class BaseActivity extends AppCompatActivity {

}
