package com.blueberry.sample.common;

/**
 * Created by blueberry on 2016/9/21.
 */

public class Config {
    public static boolean isTest;

}
