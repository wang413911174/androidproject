package com.blueberry.sample.module.http;

/**
 * Created by blueberry on 2016/8/16.
 */
public class HttpClientStack implements HttpStack {
    @Override
    public Response performRequest(Request<?> request) {
        return null;
    }
}
